#!/bin/bash

#ldd ./EUPSystemTool

target="EUPSystemTool"
toolPath=/usr/local/bin/$target

cp ./$target $toolPath
chmod 777 $toolPath
chmod 777 ./shortcut.sh
chmod 777 ./OSAppScript/*
cp -r ./OSAppScript ~/
cp ./Library.txt ~/
cp ./EUPSystemTool.policy  /usr/share/polkit-1/actions
cp ./startEUPSystemTool.sh /usr/local/bin/
cp ./shortcut.sh ~/
if [ ! -e ~/whiteList.conf ];then
	touch ~/whiteList.conf
fi
#临时切换devel
#sudo -u devel ~/shortcut.sh
