#!/bin/bash

lsblk
