iostat -d -x 1
