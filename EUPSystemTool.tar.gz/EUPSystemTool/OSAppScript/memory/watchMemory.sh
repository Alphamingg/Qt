sar --human -r -S 1 
