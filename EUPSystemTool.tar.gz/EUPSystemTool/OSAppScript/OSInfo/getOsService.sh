#!/bin/bash

systemctl list-unit-files
#cat /etc/services
#service --status-all
