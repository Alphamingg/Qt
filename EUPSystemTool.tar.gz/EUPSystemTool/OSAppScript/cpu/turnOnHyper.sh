echo on > /sys/devices/system/cpu/smt/control
