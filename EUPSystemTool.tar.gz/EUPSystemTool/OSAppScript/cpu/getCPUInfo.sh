likwid-topology -g
