cat /sys/devices/system/cpu/cpu0/cpufreq/energy_performance_available_preferences
