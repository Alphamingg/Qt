echo off > /sys/devices/system/cpu/smt/control
