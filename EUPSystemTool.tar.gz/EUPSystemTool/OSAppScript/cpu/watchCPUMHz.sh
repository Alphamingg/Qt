#!/bin/bash
watch grep \"cpu MHz\" /proc/cpuinfo
