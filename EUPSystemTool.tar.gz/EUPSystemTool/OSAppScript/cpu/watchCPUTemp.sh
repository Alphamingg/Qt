#!/bin/bash
watch sensors


