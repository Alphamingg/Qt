journalctl --no-pager --no-hostname -b -p3
