watch -n 1 uptime
