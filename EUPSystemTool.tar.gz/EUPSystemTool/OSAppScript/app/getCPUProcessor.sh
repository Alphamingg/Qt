cat /proc/cpuinfo | grep "processor" | wc -l
