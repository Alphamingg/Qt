cd /home/devel/script/GPUInfo/GpuTest_Linux_x64_0.7.0

#./GpuTest /test=fur /width=1920 /height=1080 /benchmark
./GpuTest /test=fur /width=1920 /height=1080 
