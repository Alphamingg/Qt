nvidia-smi -pl $1
