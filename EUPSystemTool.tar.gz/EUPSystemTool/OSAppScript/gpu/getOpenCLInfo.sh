clinfo
