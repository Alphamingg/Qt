#!/bin/bash
watch -ptn 0 "xdotool getmouselocation"
