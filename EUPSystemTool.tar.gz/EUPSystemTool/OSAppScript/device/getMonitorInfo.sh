#!/bin/bash
xrandr | grep -v disconnected
