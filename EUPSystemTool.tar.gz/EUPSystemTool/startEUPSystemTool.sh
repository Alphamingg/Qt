#!/bin/bash

export DISPALY=:0.0
export XAUTHORITY=/home/devel/.Xauthority

pkexec /usr/local/bin/EUPSystemTool
