#!/bin/bash

#gsettings set org.gnome.settings-daemon.plugins.media-keys custom-keybindings "[]"

custom="custom8"
oldKey=`gsettings get org.gnome.settings-daemon.plugins.media-keys custom-keybindings`
echo $oldKey

empty="[]"
if [[  $oldKey = *$empty* ]]
then
	value="'/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/$custom/']"

else
	value=", '/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/$custom/']"
fi

addKey=${oldKey/%]/$value}
echo $addKey

gsettings set org.gnome.settings-daemon.plugins.media-keys custom-keybindings "$addKey"
gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/$custom/ name "'EUPSystemTool'"
gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/$custom/ command "'/usr/local/bin/startEUPSystemTool.sh'"
gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/$custom/ binding "'<Ctrl><Shift>p'"
